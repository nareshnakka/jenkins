From `tango-icon-theme-0.8.90.tar.gz`, scaled using `jenkinsci/jenkins/war/images/svg2png`.
