ace.define("ace/snippets/latex",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "latex";

});
